#ifndef __MCP_DIS68K_H
#define __MCP_DIS68K_H

void disasm(unsigned long int start, unsigned long int end);

#endif