/*
 * Test commands
 */

#ifndef __TEST_CMDS_H
#define __TEST_CMDS_H

/*
 * Test command
 */
extern short cmd_test(short channel, int argc, char * argv[]);

#endif
